[বাংলায় দেখান](PPPoE-bn.md)

# PPPoE Process Flow

- **Customer Registration**
    - Admin can add PPPoE customers from admin panel.
        - IPv4 Address
            - Dynamic or Static IP Can be defined in the PPP Profile.
        - IPv6 Address
            - IPv6 Address Pool can be defined in the PPP Profile.

- **Customer Payment**
    - The customer will renew or purchase a new package from customer panel.

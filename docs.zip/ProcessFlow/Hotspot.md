[বাংলায় দেখান](Hotspot-bn.md)

# Hotspot Process Flow

- **Customer Registration**
    - Self registration using mobile number through hotspot login page.
    - Admin can add hotspot customers from admin panel.
    - Only mobile number is required for hotspot customer registration.

- **Customer Authentication**
    - MAC Address of the Customer's Device is used as username and password.
    - MAC Address of the Customer's Device is captured automatically during registration.
    - The user's device will be authenticated by the radius server automatically as soon as the device is connected to your network.
    
- **Customer Payment**
    - The customer will renew or purchase a new package from customer panel.

# Static IP Customer Process Flow

- **Customer Registration**
    - Admin can add Static IP customers from admin panel.

- **Customer Payment**
    - The customer will pay bills from customer panel.

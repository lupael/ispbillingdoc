# Distributors Payments

 - **আপনি আপনার কার্ড ডিস্ট্রিবিউটরদের কাছ থেকে কত টাকা কালেকশন করেছেন তা Distributors Payments -এ সংরক্ষণ করুন ।** 
  
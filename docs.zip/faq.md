# FAQ

- **সফটওয়্যার এর জন্য কত টাকা দিতে হবে?**
    - Minimum Fee 1500TK/Month OR 1TK/User/Month.
    - ধরেন আপনার কাস্টমার ১৬০০ জন তাহলে আপনাকে প্রতিমাসে ১৬০০ টাকা দিতে হবে । যদি আপনার কাস্টমার ১৫০০ জন হয় তাহলে আপনাকে প্রতিমাসে ১৫০০ টাকা দিতে হবে । যদি আপনার কাস্টমার ১০০ জন হয় তাও আপনাকে প্রতিমাসে ১৫০০ টাকা দিতে হবে।

- **সফটওয়্যার -এ কতগুলো রাউটার এড করতে পারবো?** 
    - রাউটার এড করার লিমিটেশন নাই ।

- **সফটওয়্যার -এ কতগুলো রিসেলার এড করতে পারবো?**
    - রিসেলার এড করার লিমিটেশন নাই ।

- **সফটওয়্যার টি কতগুলো কাস্টমারের লোড নিতে পারবে?**
    - আনলিমিটেড । 

- **Customer is not getting IPv6 address**
    - Check RouterOS is up-to-date.
    - Check customer is connected to the respective ppp profile (Mikrotik-Group).

- **What is the difference between API based software and Radius based software?**
    - In API based software customers will be created in your router when you will create customer in the software, but in radius based software we do not need to keep customers in the router customers credentials will be stored in the radius server.
    - In API based software to see online customers, you may need to login into the router and need API access to the router, but in radius based software you do not need to access to the router and do not require API access to router, you can see the online customers from radius server.
    - In API based software customers in router should keep in enabling state, but in radius based software we no not kept any customers in the router.
    - In API based software you cannot see the customer internet history but in the radius based software you can see the customer internet history and can download customers internet history.

- **একজন পিপিপি কাস্টমার যেদিন তার প্যাকেজের মেয়াদ শেষ হবে তারও কিছুদিন পর বিল পরিশোধ করতে চায় । কিভাবে তার  প্যাকেজের মেয়াদ বাড়াবো 
বা অটোমেটিক সাস্পেনশন বন্ধ করবো?**
    - তিন ভাবে করতে পারেন ।
      - ১। কাস্টমার যে  বিলিং প্রোফাইল টি ইউজ করেন সেটার অটোমেটিক সাস্পেনশন নো করে দিন।
      - ২। ঐ কাস্টমার এর  Validity/Suspend Date এডিট করতে পারেন ।
      - ৩। ঐ কাস্টমারের বিল এর ডিউ ডেট এডিট করতে পারেন ।




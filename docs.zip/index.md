[বাংলায় দেখান](index-bn.md)

# Features

- **Three Types of Customer Management:**
    - PPPoE
    - Hotspot
    - Static IP

- **Fast, Secure, Automated and Efficient Hotspot billing solution.**
    - Users Self Registration uses a mobile number only (Fast and Convenient)
    - The user's device will be authenticated by the radius server automatically as soon as the device is connected to your network (Secure and Efficient).
    - The user's account will be unlocked automatically as soon as he pays/renew/purchase Internet package through online payment gateway (Fast and Efficient).

- **Invoice generation and payment processing**
    - Automatically generate a monthly bill at the begging of the month for PPPoE and Static IP customers.
    - Download Invoices in PDF and Excel format.
    - SMS Notification for payments and bills.
    - Get paid instant on your bank account from your customers with online payment gateways.

- **Radius server**
    - Authentication
    - Authorization
    - Internet Usage History.

- **IPAM – IP address management**
    - Avoid Network Address overlaps.
    - Static IP for PPPoE Customers.

- **IPv6 Support**
    - For PPPoE Customers.

- **Reseller modes**
    - Easy Resell
    
- **Customer portal**
    - Customer Status
    - Internet History
    - Buy Package
    - Pay Bill

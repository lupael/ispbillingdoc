# New Customer

- From this menu, you can add new customers.

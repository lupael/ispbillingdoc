# Import PPPoE Customers

- From this menu, you can import ppp customers from mikrotik router.

# Backup Settings

- From this menu, you can set which customers will stored on which routers for backup purpose.

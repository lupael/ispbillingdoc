# Online Customers

- From this menu, you can list the online customers (ppp and hotspot)

# Customer zone
- From this menu, you can add customer zone.
- Later you can sort customers by customer zone.

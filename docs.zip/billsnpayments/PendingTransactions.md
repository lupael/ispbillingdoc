# Pending Transactions

- The customer has initiated the payment, but the payment is not executed successfully.

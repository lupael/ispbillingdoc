# Due Notifier

- Using this menu, you can send bill notification to customers.

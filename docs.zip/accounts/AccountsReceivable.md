# Accounts Receivable

- From this menu, you will see from whom and how much money you will receive.
- আপনি আপনার কোন রিসেলারের কাছ থেকে কত টাকা পাবেন তা Accounts Receivable এ দেখতে পারবেন।


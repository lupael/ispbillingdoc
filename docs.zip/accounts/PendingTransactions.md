# Pending Transactions

- In this menu you will see
    - You have paid, but the recipient has not acknowledged the payment.
    - Someone has sent money to you, but you have not acknowledged.

- আপনার রিসেলার আপনাকে টাকা পাঠানোর পর Accounts Payable থেকে Send Money করবে । আপনি যদি আপানার রিসেলার এর কাছ থেকে টাকা পেয়ে থাকেন তাহলে Pending Transactions থেকে তা confirm করবেন ।


# Settlement

- From this menu, you can set how you want to get payment from others.

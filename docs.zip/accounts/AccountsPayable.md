# Accounts Payable

- From this menu, you will see to whom and how much money you will pay.
- আপনার রিসেলারের কাছ থেকে আপনি কত টাকা পাবেন তা আপনার রিসেলার Accounts Payable থেকে দেখতে পারবেন । 


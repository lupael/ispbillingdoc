# Managers

- **What is manager?**
    - The manager can do only the assigned tasks from the following:
        - view-customer-details
        - create-customer
        - edit-customer
        - delete-customer
        - activate-customer
        - suspend-customer
        - change-customer-package
        - receive-payment
        - print-invoice
        - generate-bill
        - send-sms
        

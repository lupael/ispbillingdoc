# Operators

- **What is Operator?**
    - You can call the operator as a reseller.

- **What is operator's share?**
    - Suppose that a customer of the operator has paid 100TK, if the operator's share is 60%, the operator will get 60TK and you will get 40TK.

- **What is offline payment?**
    - If you allow offline payment for the operator, the customers of the operator can pay using recharge card.

- **What is the difference between operator and group admin?**
    - The operator is the reseller of the group admin.
    - The operator can not add packages.
    - The operator can not add billing profiles.
    - The operator can not add routers.
    - The operator cannot export or import customers.
    - The operator can not view customers of other operators.

- **Important Notes**
    - Assign packages and billing profiles after creating operator.

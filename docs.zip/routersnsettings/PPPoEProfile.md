# PPP Profile

- **What is PPP Profile?**
    - The profile will be used after authentication of the ppp customer.
    - Define IPv4 address of the customer.
    - Define IPv6 address of the customer.


# Packages

- Customers will see the packages with public visibility only.
- The operator will see the packages assigned to him only.

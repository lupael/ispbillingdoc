# IPv6 Pool

- **What is IPv6Pool?**
    - IPv6 address for PPP customers are assigned from IPv6 Pool.
    - For hotspot customers IPv6 pool is not required.

# IPv4 Pool

- **What is IPv4 pool?**
    - IPv4 address for PPP customers are assigned from IPv4 pool.
    - For hotspot customers IPv4 pool is not required.

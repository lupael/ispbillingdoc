# routers

- **What types of router is supported?**
    - Only MikroTik.

- **What is API User?**
    - API User is the system user of your mikrotik.

- **Why the software need the API user?**
    - We utilize the API user for configuring the router and to take backup of your customers into your router.

- **What Type of permissions the API user need?**
    - Since API User will write the configuration into your router so API user will need at least write permission.
    - To Import Customers from your Mikrotik to software the API user will need full permission.

- **How to Configure the router?**
    - From actions, click on configure, the router will be configured for you.

- **What is the purpose of router's system identity?**
    - For hotspot customers, from router's system identity we find out the operator of the customer and the router the customer is login from.


# Why you will pay monthly subscription fee?

- A server is running 24x7 for you.
    - Which is burning electricity.
    - Has depreciation cost.
    - Has server room cost.

- A Software team is working for maintaining the software.
    - Salary for the software engineers.
    - Hardware depreciation cost used by the software engineers.
    - The Cost of Workplace Integration.

- A Support team is working for the support.
    - Salary for the support engineers.
    - Hardware depreciation cost used by the support engineers.
    - The Cost of Workplace Integration.

**For all of this we bill 1500 BDT/ Or 1BDT/User which is higher**

**Now Calculate, how much cost, will you have, if you want to maintain the software by yourself**
